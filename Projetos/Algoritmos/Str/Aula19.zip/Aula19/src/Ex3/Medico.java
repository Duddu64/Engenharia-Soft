package Ex3;

public class Medico {
	private int crm;
	private String nome;
	private String especialidade;
	public int getCrm() {
		return crm;
	}
	public String getNome() {
		return nome;
	}
	public String getEspecialidade() {
		return especialidade;
	}
	public void setCrm(int crm) {
		this.crm = crm;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public void setEspecialidade(String especialidade) {
		this.especialidade = especialidade;
	}
	
	
}
