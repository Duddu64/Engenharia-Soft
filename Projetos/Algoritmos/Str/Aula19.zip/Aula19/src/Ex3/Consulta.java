package Ex3;

public class Consulta {
	private Paciente pacil=new Paciente();
	private Medico med=new Medico();
	public Paciente getPacil() {
		return pacil;
	}
	public Medico getMed() {
		return med;
	}
	public void setPacil(Paciente pacil) {
		this.pacil = pacil;
	}
	public void setMed(Medico med) {
		this.med = med;
	}
	
	
}
