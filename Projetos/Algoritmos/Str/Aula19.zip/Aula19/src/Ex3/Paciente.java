package Ex3;

public class Paciente {
	private int codigo;
	private String nome;
	private int idade;
	public int getCodigo() {
		return codigo;
	}
	public String getNome() {
		return nome;
	}
	public int getIdade() {
		return idade;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	
	
}
